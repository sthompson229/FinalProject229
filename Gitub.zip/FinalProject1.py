from tkinter import *

# these lines give the title and size
root = Tk()
root.title("Illness Calculator")
root.geometry("800x800")

# for the background image
mainpic = PhotoImage(file='doctor.png')
buttonpic = PhotoImage(file='exit.png')
piclabel = Label(root, image=mainpic)
piclabel.place(x=0, y=0, relwidth=1, relheight=1)

# this creates the grid of buttons and the entry bar
e = Entry(root, width=50, borderwidth=5)
e.insert(0, "What is your illness?")
e.grid(row=0, column=0, columnspan=3, padx=10, pady=10)


# this is the start of defining the buttons on screen 1
def Symptoms(string):
    e.delete(0, END)
    e.insert(0, string)


# list of all buttons in the program
Symptom1 = Button(root, text="Fever", padx=40, pady=20, command=lambda: Symptoms("Fever"))
Symptom2 = Button(root, text="Shortness of Breath", padx=40, pady=20, command=lambda: Symptoms("Shortness of Breath"))
Symptom3 = Button(root, text="Sinus Pain", padx=40, pady=20, command=lambda: Symptoms("Sinus Pain"))
Symptom4 = Button(root, text="Shivering", padx=40, pady=20, command=lambda: Symptoms("Shivering"))
Symptom5 = Button(root, text="Body Aches", padx=40, pady=20, command=lambda: Symptoms("Body Aches"))
Symptom6 = Button(root, text="Nausea", padx=40, pady=20, command=lambda: Symptoms("Nausea"))
Exitbutton = Button(root, text="Exit", image=buttonpic, padx=40, pady=40, command=root.quit)

# put buttons on screen grid

Symptom1.grid(row=1, column=1)
Symptom2.grid(row=1, column=2)
Symptom3.grid(row=1, column=3)
Symptom4.grid(row=2, column=1)
Symptom5.grid(row=2, column=2)
Symptom6.grid(row=2, column=3)
Exitbutton.grid(row=3, column=1)

root.mainloop()
